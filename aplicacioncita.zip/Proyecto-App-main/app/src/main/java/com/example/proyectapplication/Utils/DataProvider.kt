package com.example.proyectapplication.Utils

import com.example.proyectapplication.R
import com.example.proyectapplication.models.Producto

object DataProvider {
    val productosPrueba = listOf(
        Producto(1, "Torta Cuadrada de Chocolate", 45000.0, R.drawable.tortacuadradadechocolate),
        Producto(2, "Torta Cuadrada de Frutas", 50000.0, R.drawable.tortafrutillacremacuadrada),
        Producto(3, "Torta Circular de Vainilla", 40000.0, R.drawable.circularvainilla),
        Producto(4, "Torta Circular de Manjar", 42000.0, R.drawable.circularmanjar),
        Producto(5, "Torta Sin Azucar De Naranja", 42000.0, R.drawable.tortasinazucarnaranja),
        Producto(6, "Tiramisu", 5500.0, R.drawable.tiramisu)

    )

}