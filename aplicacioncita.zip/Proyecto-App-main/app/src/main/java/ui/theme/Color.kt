
package com.example.proyectapplication.ui.theme

import androidx.compose.ui.graphics.Color

val PastelPink = Color(0xFFFFC1CC)
val MintGreen = Color(0xFFA8E6CF)
val CreamWhite = Color(0xFFFFF8E7)
val ChocolateBrown = Color(0xFF6B4226)
val AccentYellow = Color(0xFFFFE082)
